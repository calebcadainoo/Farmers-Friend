

		<article class="home_container app_view_container">
			<!-- header -->
			<header class="crop_search_head crop_loc_head">
				<aside class="crop_head_inner"><div class="centroid_700">
					<br>
					<div class="header_label white_person">Speak to an Expert</div>
				</div></aside>
			</header>
			<!-- end of header -->

			<!-- section or body -->
			<section class="centroid_700 crop_section">
				<!-- topic -->
				<div class="chat_topic">
					<!-- topic text -->
					<div class="chat_topic_text grid-9"><span class="chat_topic_label">Talk to me about</span> <br><span class="chat_topic_name">Fall Armyworms </span></div>
					<!-- chat button -->
					<div class="chat_topic_button grid-3"><br>Chat</div>
				</div>

				<!-- topic -->
				<div class="chat_topic">
					<!-- topic text -->
					<div class="chat_topic_text grid-9"><span class="chat_topic_label">Talk to me about</span> <br><span class="chat_topic_name">Storing maize </span></div>
					<!-- chat button -->
					<div class="chat_topic_button grid-3"><br>Chat</div>
				</div>

				<!-- topic -->
				<div class="chat_topic">
					<!-- topic text -->
					<div class="chat_topic_text grid-9"><span class="chat_topic_label">Talk to me about</span> <br><span class="chat_topic_name">Push-pull Method against Fall Armyworms </span></div>
					<!-- chat button -->
					<div class="chat_topic_button grid-3"><br>Chat</div>
				</div>
			</section>
			<!-- end of section or body -->
		</article>

		<script>
			$(function () {
				$('.expert').addClass('menu_focus');
			});
		</script>