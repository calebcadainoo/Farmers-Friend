				
	
				<div class="spacerA"></div>
				<div class="coin_balance_bx">
					<div class="grid-4">Balance: </div>
					<div class="grid-4 boxed_coin_value">38 F&#8373;</div>
					<div class="grid-4 boxed_coin_value">$106 (US)</div>
				</div><br>

				<div class="coin_transac_btn send_money">Send Money</div>
				<br><br>
				<div class="coin_transac_btn receive_money rem_bor">Receive Money</div>

				<script>
					$(function () {
						$('.tab_pay').addClass('app_tab_select');
					});
				</script>