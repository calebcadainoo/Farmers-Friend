

		<article class="home_container app_view_container">
			<!-- header -->
			<header class="crop_search_head crop_loc_head">
				<aside class="crop_head_inner"><div class="centroid_700">
					<br>
					<div class="header_label white_people">Group Chat</div>
				</div></aside>
			</header>
			<!-- end of header -->

			<!-- section or body -->
			<section class="centroid_700 crop_section">
				<!-- topic -->
				<div class="chat_topic">
					<!-- topic text -->
					<div class="chat_topic_text grid-9"><span class="chat_topic_label">Farmers In Free State,South Africa</span></div>
					<!-- chat button -->
					<div class="chat_topic_button grid-3"><br>View</div>
				</div>

				<!-- topic -->
				<div class="chat_topic member_not">
					<!-- topic text -->
					<div class="chat_topic_text grid-9"><span class="chat_topic_label">Maize Farmers In South Africa</span></div>
					<!-- chat button -->
					<div class="chat_topic_button grid-3 not_member"><br>Join Group</div>
				</div>

				<!-- topic -->
				<div class="chat_topic member_not">
					<!-- topic text -->
					<div class="chat_topic_text grid-9"><span class="chat_topic_label">Smaller Farmers In Free State</span></div>
					<!-- chat button -->
					<div class="chat_topic_button grid-3 not_member"><br>Join Group</div>
				</div>
			</section>
			<!-- end of section or body -->
		</article>

		<script>
			$(function () {
				$('.persons').addClass('menu_focus');
			});
		</script>