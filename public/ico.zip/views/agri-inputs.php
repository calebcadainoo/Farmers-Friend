



			<div class="spacerA"></div>

			<div class="search_agribx">
				<input class="form_textbx" type="text" name="agri_input" placeholder="Search For an Agri-Input...">
			</div>

			<!-- inputlet -->
			<div class="input_let">
				50kg NPK Fertilizer
				<div class="inputlet_btn_box float_right">
					<div class="input_let_btn">View</div>
					<div class="input_let_btn">Buy</div>
				</div>
			</div>
			<!-- input let -->
			<div class="input_let">
				Farm spraying services
				<div class="inputlet_btn_box float_right">
					<div class="input_let_btn">View</div>
					<div class="input_let_btn">Buy</div>
				</div>
			</div>

			<script>
				$(function () {
					$('.tab_pur').addClass('app_tab_select');
				});
			</script>