	
	<!-- splashscreen -->
	<section class="omni_splashscreen">
		<!-- omni logo -->
		<div class="omni_logo trans animated fadeInDown">
			<img src="img/Omni AI.png" alt="">
		</div>
		<!-- powered by -->
		<div class="omni_powered trans animated fadeIn">.:: Developed Powered by ::.</div>
		<!-- limitless logo -->
		<div class="limitless_logo trans animated fadeInUp">
			<img src="img/Limitless AI.png" alt="">
		</div>
	</section>
	<!-- end of splashscreen -->