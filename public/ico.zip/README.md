# Farmers-Friend
A tool designed to improve farming efficiency &amp; enable higher crop yields by use of big data sets, user location along with machine learning algorithms &amp; predictive analysis models to provide user (farmer) with daily guidance on all activities from pre-planting to post-harvesting.

Link to project
https://www.limitlessai.org/
