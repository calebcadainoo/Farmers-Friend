<?php
	$host = "localhost";
	$user = "iaoucc_omni-user";
	$password = "iaoucc";
	$db = "iaoucc_omni-ai";
	$con = new mysqli($host,$user,$password,$db) or die($con->error);

?> 